No Man's Sky - Save Editor

To run this app, you must have Java 8 installed.
https://java.com/en/download/

Then simply run the NMSSaveEditor.bat file.

## Troubleshooting ##

If you notice anything unexpected happen while using the editor, such as crashes, try running it in debug mode instead. This will also show a console window allowing you to see any error messages.

The most common error users can get using this app, is an OutOfMemory error. If this happens, try using one of the 4G executables instead.

For anything else, visit https://github.com/goatfungus/NMSSaveEditor and lodge an issue there.

Enjoy!

- goatfungus